# Minor_dataset > 2024-02-25 2:19am
https://universe.roboflow.com/datasets-tnnrm/minor_dataset

Provided by a Roboflow user
License: CC BY 4.0

